#views catalog
###when type `gulp localhost` then everything in this catalog changed will reload browser. 