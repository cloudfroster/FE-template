#FE-template
### Individual front-end project template
### use nodejs + express + gulp + coffeescript + less + ejs + jquery1.11.2 + lessHat.less + marchen.less + normalize.css

#change log
## version 0.0.5
###### add gitignore file,now build file will not push to git. fix some bug. 

## version 0.0.4
### change gulp task:
###### `gulp`  ------ watch less, coffee, js, and views direction files.when changed compile them.
###### `gulp localhost`  ------ use browser-sync tool watch less, coffee, js, and views direction files. when change compile them and reload browser.