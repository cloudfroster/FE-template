#js common catalog
###put common coffee or js code in this catalog.