#js common catalog (for all site)
###put common coffee or js code in this catalog.