#js lib catalog (for all site)
###put lib or js code in this catalog. Generally speaking it's custom